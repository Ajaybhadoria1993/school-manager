(function () {
  "use strict";

  var form = document.getElementById("loginForm");
  var alertBox = document.getElementById("formAlert");
  var submitBtn = document.getElementById("submitBtn");
  var pwd = document.getElementById("password");
  var eyeIcon = document.getElementById("eyeIcon");
  var remember = document.getElementById("remember");
  var currentRole = "admin";

  document.getElementById("year").textContent = new Date().getFullYear();

  // ---- Role tabs ----
  document.querySelectorAll(".role").forEach(function (btn) {
    btn.addEventListener("click", function () {
      document.querySelectorAll(".role").forEach(function (b) {
        b.classList.remove("active");
        b.setAttribute("aria-selected", "false");
      });
      btn.classList.add("active");
      btn.setAttribute("aria-selected", "true");
      currentRole = btn.dataset.role;
    });
  });

  // ---- Show / hide password ----
  document.getElementById("togglePwd").addEventListener("click", function () {
    var show = pwd.type === "password";
    pwd.type = show ? "text" : "password";
    eyeIcon.src = show ? "assets/icons/eye-off.svg" : "assets/icons/eye.svg";
  });

  // ---- Remember school code + user id (password kabhi save nahi hota) ----
  try {
    var saved = JSON.parse(localStorage.getItem("edushiksha_login") || "null");
    if (saved) {
      form.schoolCode.value = saved.schoolCode || "";
      form.userId.value = saved.userId || "";
      remember.checked = true;
    }
  } catch (e) { /* ignore */ }

  // ---- Validation ----
  function setError(name, msg) {
    var field = form[name].closest(".field");
    field.classList.toggle("invalid", !!msg);
    field.querySelector(".error").textContent = msg || "";
  }

  function validate() {
    var ok = true;
    var code = form.schoolCode.value.trim();
    var id = form.userId.value.trim();
    var pass = form.password.value;

    setError("schoolCode", "");
    setError("userId", "");
    setError("password", "");

    if (!code) { setError("schoolCode", "School code daalna zaroori hai"); ok = false; }

    var isEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(id);
    var isMobile = /^[6-9]\d{9}$/.test(id);
    if (!id) { setError("userId", "Email ya mobile number daalein"); ok = false; }
    else if (!isEmail && !isMobile) { setError("userId", "Sahi email ya 10 digit mobile number daalein"); ok = false; }

    if (!pass) { setError("password", "Password daalna zaroori hai"); ok = false; }
    else if (pass.length < 6) { setError("password", "Password kam se kam 6 characters ka hona chahiye"); ok = false; }

    return ok;
  }

  function showAlert(msg, type) {
    alertBox.textContent = msg;
    alertBox.className = "alert" + (type === "success" ? " success" : "");
    alertBox.hidden = false;
  }

  // ---- Submit ----
  form.addEventListener("submit", function (e) {
    e.preventDefault();
    alertBox.hidden = true;
    if (!validate()) return;

    try {
      if (remember.checked) {
        localStorage.setItem("edushiksha_login", JSON.stringify({
          schoolCode: form.schoolCode.value.trim(),
          userId: form.userId.value.trim()
        }));
      } else {
        localStorage.removeItem("edushiksha_login");
      }
    } catch (err) { /* ignore */ }

    submitBtn.classList.add("loading");

    var payload = {
      role: currentRole,
      schoolCode: form.schoolCode.value.trim(),
      userId: form.userId.value.trim(),
      password: form.password.value
    };

    // TODO: apni backend API ka URL yahan lagayein
    fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    })
      .then(function (res) {
        if (!res.ok) throw new Error(res.status === 401 ? "Galat ID ya password" : "Server error, dobara try karein");
        return res.json();
      })
      .then(function (data) {
        showAlert("Login safal! Redirect ho raha hai...", "success");
        // TODO: token save karein aur dashboard par bhejein
        // localStorage.setItem("token", data.token);
        // window.location.href = "/dashboard";
      })
      .catch(function (err) {
        showAlert(err.message || "Kuch gadbad ho gayi, dobara try karein");
      })
      .finally(function () {
        submitBtn.classList.remove("loading");
      });
  });

  document.getElementById("forgot").addEventListener("click", function (e) {
    e.preventDefault();
    // TODO: forgot-password page ka link lagayein
    showAlert("Forgot password page abhi connect nahi hai.");
  });
})();
