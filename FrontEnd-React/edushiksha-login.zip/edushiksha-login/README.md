# EduShiksha Login Page

Responsive login page (desktop + mobile) with all icons and illustrations as SVG files.

## Folder structure

```
edushiksha-login/
├── index.html
├── css/style.css
├── js/app.js
└── assets/
    ├── icons/            (UI icons, logo)
    └── illustrations/    (school building, graduation cap, checklist, sidebar background)
```

## Use karne ka tareeka

1. Poora folder apne project mein copy karein (ya sirf `assets/` folder aur `css/js` files).
2. Browser mein `index.html` kholkar dekh sakte hain.
3. `js/app.js` mein `fetch("/api/auth/login", ...)` ko apni backend API se connect karein
   (token save aur dashboard redirect ke liye TODO comments diye hain).

## Icons list

| File | Use |
|------|-----|
| logo.svg | App logo / favicon |
| user.svg, lock.svg, mail.svg, phone.svg, school.svg | Input field icons |
| eye.svg, eye-off.svg | Password show/hide |
| arrow-right.svg | Button arrow (white) |
| check-circle.svg | Green tick |
| shield-check.svg | Security badge |
| bell.svg | Notification |
| role-admin.svg, role-teacher.svg, role-parent.svg | Role tabs |

Illustrations: `school-building.svg`, `graduation-cap.svg`, `checklist.svg`, `sidebar-bg.svg`

## Customize

- Colors: `css/style.css` ke top par `:root` variables badlein.
- Icon ka color: SVG file mein `stroke="#64748b"` ko apne color se badlein.
- Font: Poppins (Google Fonts) use hua hai; offline ke liye system font fallback hai.

## Note

Password kabhi localStorage mein save nahi hota; "Mujhe yaad rakhein" sirf School Code aur Email/Mobile yaad rakhta hai.
